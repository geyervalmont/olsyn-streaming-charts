# kit-appstreaming-session

![Version: 1.7.0-experimental](https://img.shields.io/badge/Version-1.7.0--experimental-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.7.0](https://img.shields.io/badge/AppVersion-1.7.0-informational?style=flat-square)
streamingKit application.
**Homepage:** <https://github.com/NVIDIA-Omniverse/kit-appstreaming-api>

## Overview

This chart assumes that a Kubernetes cluster is already available and configured.

## Quick start

Before installing it's worth considering Image Pull Secrets and Ingress access.

NOTE: use `--dry-run` to inspect the resulting Kubernetes manifests generated from the helm chart.

```bash
helm upgrade \
    --install \
    nv.ov.apps.streaming.kit \
    . \
    --create-namespace \
    --namespace <<NAMESPACE-NAME>> \
    --set global.imagePullSecrets[0].name=registry-secret
```

## Quick start (nvpark)

Under "omni-services-test" namespace.

```bash
helm upgrade \
    --install \
    standup \
    . \
    -n omni-services-test
    -f internal/nvpark/values.yaml
```

### Image Pull Secrets

Kit container images are hosted on **nvcr.io** behind a private repository.

Therefore, you will need to create an Image Pull Secret to be able to pull the containers within Kubernetes.

NOTE: if the `<<NAMESPACE-NAME>>` namespace does not exist, create it prior to creating the secret.

```bash

kubectl create namespace <<NAMESPACE-NAME>>

kubectl create secret docker-registry \
  registry-secret \
  --namespace <<NAMESPACE-NAME>> \
  --docker-server="nvcr.io" \
  --docker-username='$oauthtoken' \
  --docker-password=<<YOUR-NGC-API-KEY>>
```

Then during install, specify the global image pull secret.

```bash
--set global.imagePullSecrets[0].name=registry-secret
```

### Ingress Access.

The default ingress class used in this chart is **nginx**, but this can be changed by supplying `--set global.ingress.annotations."kubernetes\.io/ingress\.class"="INGRESS-CONTROLLER"`

The following two examples make use of **nginx** ingress, but other ingress providers can be utilized such as **traefik**.

It's worth getting familiar with the set of options available under the `global.ingress` setting.

#### Access via DNS

This example uses a simple local DNS setup.

For production setups you'll likely need to configure TLS cert secrets for the hosts (this is beyond the scope of this guide).

To use a custom local DNS, for example `ov.local`, we'll need to update **/etc/hosts** and map it to the Node's Internal IP.

The resulting values to specify during `helm install` will be `--set global.ingress.host="ov.local"`

This example also uses **nginx** ingress:

```bash
# install nginx controller if not already present.

helm install ingress-nginx \
  ingress-nginx \
  --repo https://kubernetes.github.io/ingress-nginx \
  --namespace ingress-nginx \
  --create-namespace \
  --set controller.service.type=NodePort \
  --set controller.service.nodePorts.http=32080

helm upgrade \
    --install \
    nv.ov.apps.streaming.kit \
    . \
    --create-namespace \
    --namespace <<NAMESPACE-NAME>> \
    --set global.imagePullSecrets[0].name=registry-secret
    --set global.ingress.annotations."kubernetes\.io/ingress\.class"="nginx" \
    --set global.ingress.host="ov.local"

kubectl get nodes -o=wide

NAME                          STATUS   ROLES                  AGE     VERSION   INTERNAL-IP   EXTERNAL-IP   OS-IMAGE       KERNEL-VERSION      CONTAINER-RUNTIME
ov-local-control-plane   Ready    control-plane,master   3h22m   v1.23.4   172.25.0.2    <none>        Ubuntu 21.10   5.15.0-27-generic   containerd://1.5.10
```

Add an entry to your **/etc/hosts**:

```bash
sudo vi /etc/hosts

172.25.0.2      ov.local
```

Get the port your NGINX is exposing in the NodePort service (32080 in this case)

```bash
kubectl get svc ingress-nginx-controller -n ingress-nginx

NAME                       TYPE       CLUSTER-IP    EXTERNAL-IP   PORT(S)                      AGE
ingress-nginx-controller   NodePort   10.96.68.95   <none>        80:32080/TCP,443:31312/TCP   47m
```

A quick check confirms we can reach the service from outside the cluster:

```bash
curl http://ov.local:32080/status
"OK"
```

#### Access via Node's IP

When the ingress host is **not** specified, the ingress controller will default to using the controller service's IP which is then routed via the Node's IP.

Here's a setup using nginx ingress without a hostname.

```bash
# install nginx controller if not already present.

helm install ingress-nginx \
  ingress-nginx \
  --repo https://kubernetes.github.io/ingress-nginx \
  --namespace ingress-nginx \
  --create-namespace \
  --set controller.service.type=NodePort \
  --set controller.service.nodePorts.http=32080

helm upgrade \
    --install \
    nv.ov.apps.streaming.kit \
    . \
    --create-namespace \
    --namespace <<NAMESPACE-NAME>> \
    --set global.imagePullSecrets[0].name=registry-secret
    --set global.ingress.annotations."kubernetes\.io/ingress\.class"="nginx" \
    --set global.ingress.host=null

kubectl get svc ingress-nginx-controller -n ingress-nginx
NAME                       TYPE       CLUSTER-IP      EXTERNAL-IP   PORT(S)                      AGE
ingress-nginx-controller   NodePort   10.43.230.160   <none>        80:32080/TCP,443:32681/TCP

kubectl -n <<NAMESPACE-NAME>> get ingress
NAME                   CLASS    HOSTS   ADDRESS         PORTS   AGE
omniverse-example   <none>   *       10.43.230.160   80      10m

kubectl get nodes -o wide
NAME                    STATUS   ROLES                  AGE   VERSION        INTERNAL-IP   EXTERNAL-IP   OS-IMAGE   KERNEL-VERSION      CONTAINER-RUNTIME
k3d-ov-local-server-0   Ready    control-plane,master   21h   v1.23.6+k3s1   172.18.0.3    <none>        K3s dev    5.15.0-43-generic   containerd://1.5.5
```

From above, port 80 is mapped to 32080 (and 443 to 32681) on the ingress-nginx-controller, and the node's internal IP is 172.18.0.3

A quick check confirms we can reach the service from outside the cluster:

```bash
curl http://172.18.0.3:32080/status
"OK"
```

## Configuration

To view values via helm use `helm show values`

**NOTE**: There are **global** values.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| global.imagePullSecrets | list | `[]` | Global image pull secrets used within the services. |
| global.ingress.annotations | object | `{}` | Global Ingress annotations. |
| global.ingress.host | string | `""` | Global Ingress host. |
| global.ingress.paths | list | `[]` | Global Ingress paths. |
| global.ingress.tls | list | `[]` | Global Ingress tls. |
| global.transportHost | string | `"0.0.0.0"` | Specify the services transport host. For IPv6 use "::". |
| streamingKit.affinity | object | `{}` | Affinity for pod assignment. https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity |
| streamingKit.aws | object | `{}` | AWS Target group ARNs When in AWS and loadbalancers, listeners and targetgroups are predefined use the following values to assign a targetgroup ARN to a TargetGroupBinding to forward traffic. |
| streamingKit.env | object | `{}` | Env for the container of the service. https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.24/#envvar-v1-core |
| streamingKit.envoy | object | `{"config":"static_resources:\n  listeners:\n  - name: webrtc_signaling_listener\n    address:\n      socket_address:\n        address: 0.0.0.0\n        port_value: 49200\n    filter_chains:\n    - filters:\n      - name: envoy.filters.network.tcp_proxy\n        typed_config:\n          \"@type\": type.googleapis.com/envoy.extensions.filters.network.tcp_proxy.v3.TcpProxy\n          stat_prefix: tcp\n          cluster: service_cluster\n          access_log:\n            - name: envoy.access_loggers.stream\n              typed_config:\n                \"@type\": type.googleapis.com/envoy.extensions.access_loggers.stream.v3.StdoutAccessLog\n                log_format:\n                  text_format: \"[%START_TIME%] \\\"%PROTOCOL%\\\" connection from %DOWNSTREAM_REMOTE_ADDRESS% to %UPSTREAM_HOST%\\n\"\n  - name: health_listener\n    address:\n      socket_address:\n        address: 0.0.0.0\n        port_value: 8080\n    filter_chains:\n    - filters:\n      - name: envoy.filters.network.http_connection_manager\n        typed_config:\n          \"@type\": type.googleapis.com/envoy.extensions.filters.network.http_connection_manager.v3.HttpConnectionManager\n          stat_prefix: health_check\n          codec_type: AUTO\n          route_config:\n            name: local_route\n            virtual_hosts:\n            - name: local_service\n              domains: [\"*\"]\n              routes:\n              - match:\n                  prefix: \"/health\"\n                direct_response:\n                  status: 200\n                  body:\n                    inline_string: \"OK\"\n          http_filters:\n          - name: envoy.filters.http.router\n  clusters:\n  - name: service_cluster\n    connect_timeout: 0.25s\n    type: STATIC\n    lb_policy: ROUND_ROBIN\n    load_assignment:\n      cluster_name: service_cluster\n      endpoints:\n      - lb_endpoints:\n        - endpoint:\n            address:\n              socket_address:\n                address: 127.0.0.1\n                port_value: 49100  # Forwarding to the stream\n","tls":{"enabled":false,"secretRef":""}}` | Envoy proxy configuration |
| streamingKit.fullnameOverride | string | `"streamingKit"` | Full override .fullname template |
| streamingKit.image.pullPolicy | string | `"Always"` | Image pull policy. |
| streamingKit.image.repository | string | `"nvcr.io/nvidia/omniverse/usd-viewer"` | Image repository. |
| streamingKit.image.tag | string | `"107.3.2"` | Image tag. |
| streamingKit.imagePullSecrets | list | `[]` | Image Pull Secrets |
| streamingKit.labels.streamType | string | `"app"` |  |
| streamingKit.labels.type | string | `"streaming"` |  |
| streamingKit.labels.version | string | `"v2"` |  |
| streamingKit.logLevel | string | `"INFO"` | Log level for the application (valid levels; INFO, DEBUG, WARN, ERROR) |
| streamingKit.monitoring.enabled | bool | `false` | Enables the creation of ServiceMonitor resource. |
| streamingKit.monitoring.prometheusNamespace | string | `"monitoring"` | Prometheus namespace. |
| streamingKit.name | string | `"streaming-kit"` | Name for all objects generated |
| streamingKit.nameOverride | string | `""` | Partially override .fullname template (maintains the release name) |
| streamingKit.nodeSelector | object | `{}` | Node labels for pod assignment. https://kubernetes.io/docs/user-guide/node-selection/ |
| streamingKit.nucleusSecretRef | string | `""` | Nucleus authentication secret to use. Secret needs to have OMNI_USER and OMNI_PASS keys |
| streamingKit.podAnnotations | object | `{}` | Pod annotations. https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/ |
| streamingKit.podSecurityContext | object | `{"runAsNonRoot":false}` | Security Context. https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-the-security-context-for-a-pod |
| streamingKit.revisionHistoryLimit | int | `5` |  |
| streamingKit.securityContext | object | `{}` | Security Context. https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-the-security-context-for-a-pod |
| streamingKit.service.annotations | object | `{}` |  |
| streamingKit.service.healthPort | int | `8080` | health port Note: This value should not have to change |
| streamingKit.service.httpPort | int | `80` | http port |
| streamingKit.service.mediaPort | int | `1024` | media port Note: This value should not have to change |
| streamingKit.service.signalingPort | int | `49100` | signaling port. Note: This value should not have to change |
| streamingKit.service.type | string | `"NodePort"` | Kubernetes service type. TODO: Check if this could work with regular cluster ips |
| streamingKit.sessionId | string | `""` | Session ID for this specific deployment |
| streamingKit.shader_cache | object | `{"enabled":true,"uri":"hsscdns://memcached-service-r3"}` | Shader cache configuration |
| streamingKit.tolerations | list | `[]` | Tolerations for pod assignment. https://kubernetes.io/docs/concepts/configuration/taint-and-toleration/ |

## License

Use of nv.ov.apps.streaming.kit is covered under "INSERT LINK HERE"
