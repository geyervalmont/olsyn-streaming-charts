{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "streamingKit.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* 
Create chart name and version as used by the chart label.
*/}}
{{- define "streamingKit.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* 
Create streamingKit fullname
*/}}
{{- define "streamingKit.fullname" -}}
{{- if .Values.streamingKit.fullnameOverride }}
{{- .Values.streamingKit.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.streamingKit.nameOverride }}
{{- if contains $name .Release.Name }}
{{- printf "%s-%s" .Release.Name .Values.streamingKit.name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s-%s" .Release.Name $name .Values.streamingKit.name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/* 
Common labels
*/}}
{{- define "streamingKit.common.labels" -}}
helm.sh/chart: {{ include "streamingKit.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}


{{/* 
streamingKit Selector labels
*/}}
{{- define "streamingKit.selectorLabels" -}}
app.kubernetes.io/name: {{ include "streamingKit.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: {{ .Values.streamingKit.name }}
{{- end }}

{{/* 
streamingKit labels
*/}}
{{- define "streamingKit.labels" -}}
{{ include "streamingKit.common.labels" . }}
{{ include "streamingKit.selectorLabels" . }}
{{- end }}

{{/*
Pod Annotations
*/}}
{{- define "streamingKit.podAnnotations" -}}
{{- $annotations := .Values.streamingKit.podAnnotations | default dict -}}
{{- toYaml $annotations -}}
{{- end }}
